package com.superapp.kingscupdrinkingamefunpartyrock.model;

/**
 * Created by ManhNV on 4/9/2016.
 */
public class Card {
    private int id;
    private String cardContent;
    private String character;
    private String name;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCardContent() {
        return cardContent;
    }

    public void setCardContent(String cardContent) {
        this.cardContent = cardContent;
    }

    public String getCharacter() {
        return character;
    }

    public void setCharacter(String character) {
        this.character = character;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
